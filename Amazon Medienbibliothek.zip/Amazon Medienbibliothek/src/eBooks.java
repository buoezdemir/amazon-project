public class eBooks extends Medium 
{
	String autor;
	int ISBN;
	int seitenzahl;
	String auflage;
	String kommentar;
	String erscheinungsdatum;
	Genre genre;

	public eBooks(String titel, String publisher, String autor, int ISBN, int seitenzahl, String auflage, String kommentar, String erscheinungsdatum, Genre genre) 
	{
		super(titel, publisher);
		this.autor = autor;
		this.ISBN = ISBN;
		this.seitenzahl = Sseitenzahl;
		this.auflage = auflage;
		this.kommentar = kommentar;
		this.erscheinungsdatum = erscheinungsdatum;
		this.genre = genre;
	}
	
	public void setAutor(String autor)
	
	{
		this.autor = autor;
	}
	
	public void setISBN(int ISBN)
	
	{
		this.ISBN = ISBN;
	}
	
	public void setSeitenzahlt(int seitenzahl)
	
	{
		this.seitenzahl = seitenzahl;
	}
	
	public void setAuflage (String auflage)
	
	{
		this.auflage = auflage;
	}
	
	public void setKommentar (String kommentar)
	
	{
		this.kommentar = kommentar;
	}
	
	public void setErscheinungsdatum (String erscheinungsdatum)
	
	{
		this.erscheinungsdatum = erscheinungsdatum;
	}
	
	public void setGenre(Genre genre)
	
	{
		this.genre = genre;
	}
	
	public String getAutor()
	
	{
		return autor;
	}
	
	public int getISBN()
	
	{
		return ISBN;
	}
	
	public int getSeitenzahll()
	
	{
		return seitenzahl;
	}
	
	public String auflage ()
	
	{
		return auflage;
	}
	
	
	public String getKommentar()
	
	{
		return kommentar;
	}
	
	public String getErscheinungsdatum ()
	
	{
		return erscheinungsdatum;
	}
	
	public Genre getGenre()
	
	{
		return genre;
	}
	
	public void anzeigen()
	{
		super.anzeigen();
		System.out.println("Autor: " + autor + "\n" + "ISBN: " + ISBN + "\n" + "Seitenzahl: " + seitenzahl + "\n" + "Auflage: " + auflage + "\n" +"Kommentar: " + kommentar + "\n" + "Erscheinungsdatum: " + erscheinungsdatum + "\n" + genre + "\n");
	}

}
