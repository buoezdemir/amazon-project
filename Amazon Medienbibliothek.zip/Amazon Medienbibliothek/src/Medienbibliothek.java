import java.util.ArrayList;
 
public class Medienbibliothek 
{

	private ArrayList<Medium> mediumListe;
	
public Medienbibliothek() 
{
		mediumListe = new ArrayList<Medium>();
}
	
public void medienHinzufuegen(Medium m)
{

 mediumListe.add(m);
}


public void anzeigen()

{
for(Medium m : mediumListe)	

{
	m.anzeigen();
}
}

public void nachTitelAnzeigen(String titel){
    for(Medium m: mediumListe){
         if(m.getTitel().toLowerCase().trim().equals(titel.toLowerCase().trim())){
             m.anzeigen();
         }
     }
}
}

