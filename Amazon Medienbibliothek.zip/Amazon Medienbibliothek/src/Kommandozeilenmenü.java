import java.util.Scanner;

public class Kommandozeilenmen� {

	Scanner scan;
	Medienbibliothek m = new Medienbibliothek();

	public Kommandozeilenmen�() {
		this.scan = new Scanner(System.in);
	}

	public void Men�Anzeigen() {
		System.out.println("MEN�");
		System.out.println("1) Alle Medien anzeigen");
		System.out.println("2) Medien suchen nach Titel");
		System.out.println("3) Medien hinzuf�gen Film oder eBook");
	}

	public void start() {
		String s = "-";
		while (!s.equals("3")) {
			Men�Anzeigen();
			s = scan.nextLine();
			switch(s)
			{
			case "1":
					anzeigen();
				break;
			case "2":
					anzeigenNachTitel(s.substring(1));
				break;
			case "3":
				mediumHinzuf�ge();
				break;
			}
		}
		scan.close();
	}
	
	
	private void anzeigen() {
		m.anzeigen();
		
	}
	
	private void anzeigenNachTitel(String titel) {
		m.nachTitelAnzeigen(titel);
		
	}
	
	private void mediumHinzuf�ge() {
		Medium md = neuesMedium();
		System.out.println("Was wollen Sie einf�gen ein Film oder ein eBook?");
		String mediumName = scan.nextLine();
		if(mediumName.equals("Film")) {
			System.out.println("Geben Sie die Spielzeit in Minuten ein");
			int spielzeit = scan.nextInt();
			System.out.println("Ist der Film UHD (1 = Ja 0 = Nein)");
			boolean UHD = scan.nextInt()== 1 ?true:false;
			System.out.println("Ist der Film HD (1 = Ja 0 = Nein)");
			boolean HD = scan.nextInt()== 1 ?true:false;
			System.out.println("Geben Sie ein Kommentar ein");
			String kommentar = scan.nextLine();
			System.out.println("Geben Sie das Erscheinungsdatum ein");
			String erscheinungsdatum = scan.nextLine();
			System.out.println("Geben Sie das Genre ein");
			Genre genre = new Genre(scan.nextLine());
			m.medienHinzufuegen(new Filme(md.getTitel(),md.getPublisher(),spielzeit,UHD, HD,kommentar,erscheinungsdatum, genre));	
		}
		else
			if(mediumName.equals("eBook"))
			{
				System.out.println("Geben Sie einen Autor ein");
				String autor = scan.nextLine();
				System.out.println("Geben Sie die 8-stellige ISBN ein");
				int ISBN = scan.nextInt();
				System.out.println("Geben Sie die Seitenzahl ein");
				int seitenzahl = scan.nextInt();
				System.out.println("Geben Sie die Auflage ein");
				String auflage = scan.nextLine();
				System.out.println("F�gen Sie ein Kommentar zu dem eBook hinzu");
				String kommentar = scan.nextLine();
				System.out.println("Geben Sie das Erscheinungsdatum ein");
				String erscheinungsdatum = scan.nextLine();
				System.out.println("Geben Sie das Genre ein");
				Genre genre = new Genre(scan.nextLine());
				m.medienHinzufuegen(new eBooks(md.getTitel(), md.getPublisher(), autor, ISBN, seitenzahl, auflage, kommentar, erscheinungsdatum, genre));
			}
		
	}
	
	private Medium neuesMedium() {
		System.out.println("Geben sie ein Titel ein");
		String titel = scan.nextLine().trim();
		System.out.println("Geben sie ein Publisher ein");
		String publisher = scan.nextLine().trim();
		return new Medium(titel, publisher);
	}
}

