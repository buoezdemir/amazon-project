
public class App {

	
	public static void main (String [] args)
	{
		Kommandozeilenmen� k = new Kommandozeilenmen�();
		k.start();
		
	}

}
