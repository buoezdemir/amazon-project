
public class App {

	
	public static void main (String [] args)
	{
		Filme f = new Filme("Pirats of the Carabien", "Ubisoft", 192, true, true, "Sehr interessant", "14.03.2015", new Genre("Action"));
		eBooks e = new eBooks ("Nathan der Weise", "Books4u","Gotthold Ephraim Lessing", 158974512, 202,"1. Auflage", "Langweilig", "14.02.1723", new Genre("Religion"));
		Medienbibliothek m = new Medienbibliothek();
		m.medienHinzufuegen(f);
		m.medienHinzufuegen(e);
		m.nachTitelAnzeigen("Pirats of the Carabien");
		m.nachTitelAnzeigen("Nathan der Weise");
		m.anzeigen();
		Kommandozeilenmen� k = new Kommandozeilenmen�();
		k.start();
		
	}

}
