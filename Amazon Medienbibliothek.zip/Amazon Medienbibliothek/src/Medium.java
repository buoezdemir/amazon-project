
public class Medium {
	
	String titel;
	String publisher;
	Genre genre;
	Urheber urheber;
	
public Medium (String titel, String publisher)

	{
	super();
	this.titel = titel;
	this.publisher = publisher;
	}

public void setTitel(String titel)

	{
	this.titel = titel;
	}

public void setPublisher (String publisher)

	{
	this.publisher = publisher;	
	}

public String getTitel()

	{
	return titel;
	}

public String getPublisher()

	{
	return publisher;
	}

public void anzeigen()
	
	{
	System.out.println("Titel: " + titel + " Publisher: " + publisher);
	}

}
