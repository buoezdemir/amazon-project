public class Filme extends Medium 
{
	String titel;
	String regisseur;
	int spielzeit;
	boolean UHD;
	boolean HD;
	String kommentar;
	String erscheinungsdatum;
	Genre genre;
	

	public Filme(String titel, String publisher, int spielzeit, boolean UHD, boolean HD, String kommentar, String erscheinungsdatum, Genre genre) 
	
	{
		super(titel, publisher);
		this.spielzeit = spielzeit;
		this.UHD = UHD;
		this.HD = HD;
		this.kommentar = kommentar;
		this.erscheinungsdatum = erscheinungsdatum;
		this.genre = genre;
	
	}
	
	public void setSpielzeit(int spielzeit)
	
	{
		this.spielzeit = spielzeit;
	}
	
	public void setUHD(boolean UHD)
	
	{
		this.UHD = UHD;
	}
	
	public void setHD (boolean HD)
	
	{
		this.HD = HD;
	}
	
	public void setKommentar (String kommentar)
	
	{
		this.kommentar = kommentar;
	}
	
	public void setErscheinungsdatum (String erscheinungsdatum)
	
	{
		this.erscheinungsdatum = erscheinungsdatum;
	}
	
	public void setGenre(Genre genre)
	
	{
		this.genre = genre;
	}
	
	public int getSpielzeit()
	
	{
		return spielzeit;
	}
	
	public boolean getUHD()
	
	{
		return UHD;
	}
	
	public boolean getHD()
	
	{
		return HD;
	}
	
	public String getKommentar()
	
	{
		return kommentar;
	}
	
	public String getErscheinungsdatum ()
	
	{
		return erscheinungsdatum;
	}
	
	public Genre getGenre()
	
	{
		return genre;
	}
	
	public void anzeigen()
	
	{
		super.anzeigen();
		System.out.println( "Regisseur: " + regisseur +"\n" +"Spielzeit: " + spielzeit + "\n" +"UHD: "+ UHD  + "\n" +"HD: " + HD + "\n" + "Kommentar: " + kommentar + "\n" + "Erscheinungsdatum: " + erscheinungsdatum + "\n"  + genre + "\n") ;
	}

}
